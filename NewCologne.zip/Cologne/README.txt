Note, that the osm file is not included in this release. It can be taken from the TAPASColgne-0.24.0 release
The network is built with cologne.netccfg to import the OSM data.
The routing is performed dynamically while the simulation runs (one-shot assignment).
