#!/usr/bin/env python
'''
Created on Oct 11, 2013

@author: Guilherme
'''

from bs4 import BeautifulSoup

if __name__ == "__main__":
    f = open("cologne.net.xml")
    data = f.read()
    f.close()
    
    f = open("cologne.poly.xml", "w")
    parser = BeautifulSoup(data)
    for element in parser.findAll("poly"):
        if "building" in element["type"]:
            element["type"] = "building"
    f.write(parser.prettify())
    f.close()
            