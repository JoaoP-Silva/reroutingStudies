#!/usr/bin/env python
'''
Created on Oct 12, 2013

@author: Guilherme
'''

from bs4 import BeautifulSoup

if __name__ == "__main__":
    f = open("cologne.rou.xml")
    data = f.read()
    f.close()
    
    f = open("cologne.rou.xml", "w")
    parser = BeautifulSoup(data)
    for element in parser.findAll("vehicle"):
        depart = float(element["depart"]) - 21600.0
        element["depart"] = str(depart)
    f.write(parser.prettify())
    f.close()
            