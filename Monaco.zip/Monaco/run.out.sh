#!/bin/bash

mkdir -p out

sumo -c most.out.sumocfg
